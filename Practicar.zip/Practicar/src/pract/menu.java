package pract;

import java.util.ArrayList;
import java.util.Scanner;

public class menu {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		ArrayList <String> notas = new ArrayList<String>();
		
		
		int opcion = 0;
		while(opcion != 2) {
			System.out.println("-------------");
			System.out.println("MENÚ");
			System.out.println("1.Agregar ");
			System.out.println("2.Eliminar");
			System.out.println("3.Mostrar tareas");
			System.out.println("4.Salir");
			System.out.println("-------------");
			System.out.println("Elije una opción :");
			opcion = teclado.nextInt();
			teclado.nextLine();
			
			//conditions about program
			if (opcion == 1) {
				System.out.println("Introduce una nota:");
				String nota = teclado.nextLine();
				notas.add(nota);
				System.out.println("La nota" + nota + "se ha agregado correctamente");
			}
			
			if (opcion == 2) {
				System.out.println("Elije la nota a eliminar:");
				String nota_delete = teclado.nextLine();
				notas.remove(nota_delete);
			}
			
			if (opcion == 3) {
				System.out.println("Mostramos las tareas");
				for(int i = 0 ; i < notas.size() ; i++) {
					System.out.println(notas.get(i));
				}
			}
			
			if(opcion == 4) {
				System.out.println("Adiós!");
				break;
			}				
		}
	}
}
