package pract;
import java.util.LinkedList;

public class practicar_lenguaje {
	
	
	public static void main(String[] args)
	{
		//System.out.println("Hola Mundo");
		/*
		String[] nombres = new String[]{"Paco","Jesus","Pancho"};
		
		for(int i = 0 ; i < nombres.length; i++) {
			System.out.println(nombres[i]);
		}
		*/
		/**
		String[] nombres = new String[4];
		nombres[0] = "Basilio";
		nombres[1] = "Conrado";
		nombres[2] = "Manuel";
		nombres[3] = "Carletto";
		
		for(int i = 0 ; i < nombres.length ; i++) {
			System.out.println(nombres[i]);
		}
		*/
		
		LinkedList <String> nombres = new LinkedList<String>();
		nombres.add("José");
		nombres.add("Pepé");
		
		System.out.println(nombres); 
	}
}
